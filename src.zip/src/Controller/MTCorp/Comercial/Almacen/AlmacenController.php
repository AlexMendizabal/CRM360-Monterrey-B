<?php

declare(strict_types=1);

namespace App\Controller\MTCorp\Comercial\Almacen;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\HttpFoundation\JsonResponse;
use Doctrine\DBAL\Driver\Connection;
use Symfony\Component\HttpFoundation\Request;
use App\Controller\Common\Services\FunctionsController;



class AlmacenController extends AbstractController
{
    /**
     * @Route(
     *  "/comercial/almacen/get_almacen",
     *  name="comercial.almacen-get_almacen",
     *  methods={"GET"},
     * )
     * @return JsonResponse
     */
    public function getAlmacen(Connection $connection, Request $request)
    {
        $FunctionsController = new FunctionsController();
        $almacen = $connection->fetchAllAssociative('SELECT id, codigo_almacen, nombre_deposito FROM TB_DEPO_FISI_ESTO WHERE estado_deposito = ? ORDER BY codigo_almacen DESC', [1]);
        return $FunctionsController->Retorno(true, null, $almacen, Response::HTTP_OK);
    }
    

    /**
     * @Route(
     *  "/comercial/almacen/centros_logisticos",
     *  name="comercial.almacen-centro_logistico",
     *  methods={"GET"},
     * )
     * @return JsonResponse
     */
    public function getCentroLogistico(Connection $connection, Request $request)
    {
        try {
            $res = $connection->query("SELECT * FROM CentrosLogisticos")->fetchAll();
            if (count($res) > 0 && !isset($res[0]['message'])) {
                $FunctionsController = new FunctionsController();
                return $FunctionsController->Retorno(true, null, $res, Response::HTTP_OK);
            } else if (count($res) > 0 && isset($res[0]['message'])) {
                $FunctionsController = new FunctionsController();
                return $FunctionsController->Retorno(true, $res[0]['message'], null, Response::HTTP_OK);
            } else {
                $FunctionsController = new FunctionsController();
                return $FunctionsController->Retorno(false, null, null, Response::HTTP_OK);
            }
        } catch (\Throwable $e) {
            $FunctionsController = new FunctionsController();
            return $FunctionsController->Retorno(false, 'Erro ao retornar dados.', $e->getMessage(), Response::HTTP_BAD_REQUEST);
        }
    }
}


