<?php

phpinfo( );

?>